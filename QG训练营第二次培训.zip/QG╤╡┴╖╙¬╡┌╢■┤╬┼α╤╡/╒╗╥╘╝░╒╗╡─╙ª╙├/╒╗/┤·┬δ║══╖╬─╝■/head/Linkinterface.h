#ifndef __SQINTERFACE_H__
#define __SQINTERFACE_H__

#include "LinkStackmain.h"

//���溯��
void interface();

#endif 
