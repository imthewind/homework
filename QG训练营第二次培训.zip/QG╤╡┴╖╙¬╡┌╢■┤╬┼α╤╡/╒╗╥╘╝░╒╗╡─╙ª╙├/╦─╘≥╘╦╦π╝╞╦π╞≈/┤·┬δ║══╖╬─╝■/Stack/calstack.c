#include "calmain.h"

Status Stack_Init(SqStack* s)
{
	s->base = (ElemType*)malloc(STACK_INIT_SIZE * sizeof(ElemType));
	if (!s->base)
		return ERROR;
	else
	{
		s->top = s->base;
		s->stacksize = STACK_INIT_SIZE;
	}
	return SUCCESS;
}

Status anStack_Init(ansqstack* s)
{
	s->base = (double*)malloc(STACK_INIT_SIZE * sizeof(double));
	if (!s->base)
		return ERROR;
	else
	{
		s->top = s->base;
		s->stacksize = STACK_INIT_SIZE;
	}
	return SUCCESS;
}

Status Stack_Push(SqStack* s, ElemType data)
{
	if (Stack_Isempty(s))
		return ERROR;
	if (s->top - s->base >= STACK_INIT_SIZE)
	{
		s->base = (ElemType*)realloc(s->base, (s->stacksize + STACK_ADD) * sizeof(ElemType));
		if (!s->base) exit(0);
		s->top = s->base + s->stacksize;
		s->stacksize += STACK_ADD;
	}
	*(s->top) = data;
	s->top++;
	return SUCCESS;
}

Status anStack_Push(ansqstack* s, double data)
{
	if (Stack_Isempty(s))
		return ERROR;
	if (s->top - s->base >= STACK_INIT_SIZE)
	{
		s->base = (double*)realloc(s->base, (s->stacksize + STACK_ADD) * sizeof(double));
		if (!s->base) exit(0);
		s->top = s->base + s->stacksize;
		s->stacksize += STACK_ADD;
	}
	*(s->top) = data;
	s->top++;
	return SUCCESS;
}

Status Stack_Pop(SqStack* s, ElemType* data)
{
	if (Stack_Isempty(s))
		return ERROR;
	else
		*data = *--(s->top);
	//free(s->top);
	return SUCCESS;
}

Status anStack_Pop(ansqstack* s, double* data)
{
	if (Stack_Isempty(s) || s->top == s->base)
		return ERROR;
	else
		*data = *--(s->top);
	//free(s->top);
	return SUCCESS;
}

Status Stack_Isempty(SqStack* s)
{
	if (s == NULL)return SUCCESS;
	else return ERROR;
}

Status Stack_Destroy(SqStack* s)
{
	if (Stack_Isempty(s))
		return ERROR;
	int i, len = s->stacksize;
	for (i = 0; i < len; i++)
	{
		free(s->base);
		s->base++;
	}
	s->base = s->top = NULL;
	s->stacksize = 0;
	return SUCCESS;
}

Status anStack_Destroy(ansqstack* s)
{
	if (Stack_Isempty(s))
		return ERROR;
	int i, len = s->stacksize;
	for (i = 0; i < len; i++)
	{
		free(s->base);
		s->base++;
	}
	s->base = s->top = NULL;
	s->stacksize = 0;
	return SUCCESS;
}

int Stack_Length(SqStack* s)
{
	if (Stack_Isempty(s))
		return ERROR;
	return s->top - s->base;
}

ElemType Stack_Topvalue(SqStack* s)
{
	if (Stack_Isempty(s) || s->top==s->base)
		return;
	return *(s->top - 1);
}

char* user_input()
{
	int i = 0;
	bool flag = 0;//������
	int panduan1 = 0, panduan2 = 0;
	ElemType* p = (ElemType*)malloc(sizeof(ElemType) * INPUTMAX);
	printf("ע�����\n");
	printf("1����һλ�ַ��벻Ҫ�����������\n");
	printf("2�������ʱ���м䲻Ҫ�пո���з�\n");
	printf("3����Ҫ�����������\n");
	printf("4��֧��С�����㣨�������ֳ��Ȳ�Ҫ����10��\n");
	printf("5��������Ϻ��ڽ�β���ϡ�=�������س�������1+1=)\n");
	while (flag == 0)
	{
		flag = 1;
		for (i = 0;; i++)//�û����룬ֱ��=��
		{
			scanf("%c", p + i);
			if (*(p + 0) == '*' || *(p + 0) == '/' || *(p + 0) == '.' || *(p + 0) == ')')
			{
				printf("������������������������룡����ʾ������ȷ�����һ�����֣�\n");
				flag = 0;
				fflush(stdin);//��ռ��̻�����
				while (getchar() != '\n')
					continue;//һֱ����ֱ���������з�
				break;
			}
			if (*(p + i) == '=') break;
			if (user_error(*(p + i)))
			{
				fflush(stdin);
				while (getchar() != '\n')
					continue;
				printf("������������������������룡\n");
				flag = 0;
				break;
			}
		}
	/*	for (int j = 0;; j++)
		{
			if (*(p + j) == '=') break;
			if (*(p + j) == '(') panduan1++;
			if (*(p + j) == ')') panduan2++;
			if (*(p + j) == '+' || *(p + j) == '-' || *(p + j) == '*' || *(p + j) == '/' || *(p + j) == '(')
			{
				if (*(p + j - 1) == '+' || *(p + j - 1) == '-' || *(p + j - 1) == '*' || *(p + j - 1) == '/')
					printf("������������������������룡����ʾ�����Ż��ң�\n");
				flag = 0;
				panduan1 = 0;
				panduan2 = 0;
				break;
			}
		}
		if (panduan1 != panduan2)
		{
			printf("������������������������룡����ʾ����������������һ�£�\n");
			flag = 0;
			panduan1 = 0;
			panduan2 = 0;
		}*/
	}
	int length = i;//��¼�ַ�����
	if (*(p + 0) == '-')//�����һλ�ַ���-��
	{
		for (i = length; i >= 0; i--)
			*(p + i + 1) = *(p + i);
		*(p + 0) = '0';//ǰ���0
		length += 1;
	}
	for (i = length; i>0; i--)//-�ż��ϣ�0��
	{
		if (*(p + i) >= '0' && *(p + i) <= '9')
		{
			if (*(p + i - 1) == '-')
			{
				if (*(p + i - 2) == '*' || *(p + i - 2) == '/' || *(p + i - 2) == '(')
				{
					int j;
					for (j = length; j > i; j--)
						*(p + j + 3) = *(p + j);
					*(p + j + 2) = *(p + j);
					*(p + j + 3) = ')';
					*(p + j + 1) = *(p + j - 1);
					*(p + j) = '0';
					*(p + j - 1) = '(';
					length += 3;//���峤�ȼ�3
				}
			}
		}
	}
	return p;
}

Status user_error(char a)
{
	if ((a >= '0' && a <= '9') || (a == '+' || a == '-' || a == '*' || a == '/' || a == '(' || a == ')' || a == '.'))
		return ERROR;
	else
		return SUCCESS;
}

double Get_Value(char* q)
{
	int i = 0, j = 0, k = 0;
	int flag = 0;//�����ű��
	SqStack* in = (SqStack*)malloc(sizeof(SqStack));
	if (!Stack_Init(in))
		printf("��ʼ��ʧ�ܣ�\n");
	ansqstack* out = (ansqstack*)malloc(sizeof(ansqstack));
	if (!anStack_Init(out))
		printf("��ʼ��ʧ�ܣ�\n");
	for (i = 0; *(q + i) != '='; i++)
	{
		if (*(q + i) == '(') flag++;
		for (k = 0; ; k++)
		{
			if (*(q + i + k) == '-' || *(q + i + k) == '+' || *(q + i + k) == '*' || *(q + i + k) == '/' || *(q + i + k) == '(' || *(q + i + k) == ')' || *(q + i + k) == '=')
				break;//��������
			//printf("\n*(q+%d+%d)=%c\n", i, k, *(q + i + k));
			resource[j].arr[k] = *(q + i + k);//j��ʾ�ڼ�������
			resource[j].length++;
		}
		if (k != 0)
		{
			i += (k - 1); //printf("\ni=%d\n", i);
			j++;
			//printf("\n*(q+i)=%c\n", *(q + i));
			continue;
		}
		if (Stack_Length(in) == 0)
		{
			if (!Stack_Push(in, *(q + i)))
				exit(0);
		}
		else
		{
			if (In_Compare(*(q + i), Stack_Topvalue(in)))//ѹջ
			{
				if (!Stack_Push(in, *(q + i)))
					exit(0);
			}
			else//��ջ
			{
				if (*(q + i) != ')')
				{
					if (flag == 0)
					{
						while (Stack_Length(in) != 0)
						{
							if (!Stack_Pop(in, &resource[j].arr[0]))
								exit(0);
							else resource[j].length = 1;
							j++;
						}
					}
					else
					{
						while (*--(in->top) != '(')
						{
							resource[j].arr[0] = *(in->top);
							resource[j].length = 1;
							j++;
						}
						(in->top)++;
					}
					if (!Stack_Push(in, *(q + i)))
						exit(0);
				} 
				else
				{
					while (*--(in->top) != '(')
					{
						resource[j].arr[0] = *(in->top);
						resource[j].length = 1;
						j++;
					}
					flag--;
				}
			}
		}
	}
	if (*(q + i) == '=')
	{
		while (in->top != in->base)
		{
			if (!Stack_Pop(in, &resource[j].arr[0]))
				exit(0);
			else resource[j].length = 1;
			j++;
		}
	}
	for (i = 0; i < j; i++)
	{
		if ((resource[i].arr[0] >= '0' && resource[i].arr[0] <= '9'))
		{
			if(!anStack_Push(out, char_to_double(&resource[i].arr,resource[i].length)))
				exit(0);
		}
		else
		{
			double val1, val2, * e1 = &val1, *e2 = &val2;
			switch (resource[i].arr[0])
			{
			case '+':if (!anStack_Pop(out, e1))
				exit(0);
				if (!(out->top == out->base))
				{
					if (!anStack_Pop(out, e2))
						exit(0);
				}
				else val2 = 0;
				if (!anStack_Push(out, val1+val2))
					exit(0);
				break;
			case '-':if (!anStack_Pop(out, e1))
				exit(0);
				if (!(out->top == out->base))
				{
					if (!anStack_Pop(out, e2))
						exit(0);
					if (!anStack_Push(out, val2 -  val1))
						exit(0);
				}
				else {
					if (!anStack_Push(out, val1))
						exit(0);
				}
				break;
			case '*':if (!anStack_Pop(out, e1))
				exit(0);
				if (!(out->top == out->base))
				{
					if (!anStack_Pop(out, e2))
						exit(0);
					if (!anStack_Push(out, val1 * val2))
					exit(0);
				}
				else {
					if (!anStack_Push(out, val1))
						exit(0);
				}
				break;
			case '/':if (!anStack_Pop(out, e1))
				exit(0);
				if (!(out->top == out->base))
				{
					if (!anStack_Pop(out, e2))
						exit(0);
					if (!anStack_Push(out, val2 / val1))
						exit(0);
				}
				else {
					if (!anStack_Push(out, val1))
						exit(0);
				}
				break;
			default:
				break;
			}
		}
	}
	double result, * e3 = &result;
	if (!anStack_Pop(out, e3))
		exit(0);
	/*if (!Stack_Destroy(in))
		exit(0);
	if (!anStack_Destroy(out))
		exit(0);*/
	memset(resource, 0, sizeof(struct temp)* INPUTMAX);//���
	return result;
}

double char_to_double(char* arr, int length)
{
	double value = 0;
	int i = 0, dian = -1;//�ж���С����
	for (i = 0; i < length; i++)
	{
		if (*(arr + i) == '.')
		{
			dian = i;
			break;
		}
	}
	if (dian == -1)
	{
		for (i = 0; i < length; i++)
			value += (*(arr + i) - '0') * pow(10, (length - i - 1));
	}
	else
	{
		for (i = 0; i < dian; i++)
			value += (*(arr + i) - '0') * pow(10, (dian - i -1));
		for(int wei = length - dian - 1;wei>0;wei--)//��λС����
			value += (*(arr + i + wei) - '0') * pow(10, -wei);
	}
	return value;
}

Status In_Compare(ElemType a1, ElemType a2)//a1ΪԪ�أ�a2λջ��Ԫ�أ�����Ҫ��ջ�ķ���1����Ҫ�ķ���0
{
	if (a1 == '+' || a1 == '-')
	{
		if (a2 == '+') return ERROR;
		else if (a2 == '-') return ERROR;
		else if (a2 == '*') return ERROR;
		else if (a2 == '/') return ERROR;
		else if (a2 == '(') return SUCCESS;
		else if (a2 == ')') return ERROR;
	}
	if (a1 == '*' || a1 == '/')
	{
		if (a2 == '+') return SUCCESS;
		else if (a2 == '-') return SUCCESS;
		else if (a2 == '*') return ERROR;
		else if (a2 == '/') return ERROR;
		else if (a2 == '(') return SUCCESS;
		else if (a2 == ')') return ERROR;
	}
	if (a1 == '(')
	{
		if (a2 == '+') return SUCCESS;
		else if (a2 == '-') return SUCCESS;
		else if (a2 == '*') return SUCCESS;
		else if (a2 == '/') return SUCCESS;
		else if (a2 == '(') return SUCCESS;
		else if (a2 == ')') return ERROR;
	}
	if (a1 == ')')
	{
		if (a2 == '+') return ERROR;
		else if (a2 == '-') return ERROR;
		else if (a2 == '*') return ERROR;
		else if (a2 == '/') return ERROR;
		else if (a2 == '(') return ERROR;
		else if (a2 == ')') return ERROR;
	}
}